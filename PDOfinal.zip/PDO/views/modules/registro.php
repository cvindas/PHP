<h1>REGISTRO DE USUARIO</h1>

<form method="post">

	<input type="text" placeholder="Usuario" name="usuario" id="usuario" required>

	<input type="password" placeholder="Contraseña" name="password" id="password" required>

	<input type="email" placeholder="Email" name="email" id="email" required>

	<input type="submit" value="Enviar">

</form>

<?php
$registro = new MvcController();
$registro -> registroUsuarioController();

if(isset($_GET["action"])){
	if($_GET["action"]=="registro-ok"){
		echo "Registro Exitoso";
	}else if($_GET["action"]=="registro-error"){
		echo "Ocurrió un error, vuelva a intentarlo más adelante";
	}
}

 ?>
