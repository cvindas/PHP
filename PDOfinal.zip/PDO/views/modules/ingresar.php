<h1>INGRESAR</h1>

	<form method="post">

		<input type="text" placeholder="Usuario" name="usuario" id="usuario" required>

		<input type="password" placeholder="Contraseña" name="password" id="password" required>

		<input type="submit" value="Enviar">

	</form>

<?php
	$ingreso = new MvcController();
	$ingreso -> ingresoUsuarioController();

	if(isset($_GET["action"])){
		if($_GET["action"]=="ingreso-error"){
			echo "Falló al Ingresar, usuario o clave incorrecta.";
		}
	}
 ?>
