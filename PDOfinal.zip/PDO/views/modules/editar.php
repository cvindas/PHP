<?php

	session_start();

	if(!$_SESSION["validar"]){
		header("location:index.php?action=ingreso-error");
		exit();
	}


 ?>
<h1>EDITAR USUARIO</h1>

<form method="post" >

<?php

	$editarUsuario = new MvcController();
	$editarUsuario -> editarUsuarioController();
	$editarUsuario -> actualizarUsuarioController();

 ?>

</form>

<?php

if(isset($_GET["action"])){
	if($_GET["action"]=="editar-error"){
		echo "Occurrio un error al editar el usuario";
	}
}

 ?>
