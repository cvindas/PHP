<?php
session_start();

 if( !$_SESSION["validar"] ){
	 header("location:index.php?action=ingreso-error");
	 exit();
 }

 ?>

 <h1>USUARIOS</h1>

	<table border="1">
		<thead>
			<tr>
				<th>Usuario</th>
				<th>Contraseña</th>
				<th>Email</th>
				<th></th>
				<th></th>
			</tr>
		</thead>
		<tbody>
			<?php
      $vistaUsuarios = new MvcController();
      $vistaUsuarios->vistaUsuariosController();
       ?>
		</tbody>
	</table>
<?php

$vistaUsuarios->borrarUsuariosController();

if(isset($_GET["action"])){
	if($_GET["action"]=="usuarios-ok"){
		echo "Bienvenido!";
	}else if($_GET["action"]=="usuarios-eliminado-ok"){
		echo "Usuario Borrado Correctamente";
	} else if($_GET["action"]=="usuarios-eliminado-error"){
		echo "Ocurrió un error al Borrar el Usuario";
	}else if($_GET["action"]=="editar-ok"){
		echo "Usuario editado Correctamente.";
	}
}

 ?>
