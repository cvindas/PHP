<?php

class MvcController{

	#LLAMADA A LA PLANTILLA
	#-------------------------------------

	static public function pagina(){

		include "views/template.php";

	}

	#ENLACES
	#-------------------------------------

	static public function enlacesPaginasController(){

		if(isset( $_GET['action'])){

			$enlaces = $_GET['action'];

		}else{

			$enlaces = "index";
		}

		$respuesta = Paginas::enlacesPaginasModel($enlaces);

		include $respuesta;

	}

	#Registro de usuarios
	#-------------------------------------
	static public function registroUsuarioController(){
		#var_dump($_POST);

		if( isset($_POST["usuario"]) && isset($_POST["password"]) && isset($_POST["email"]) ){
			$datosController = array(	"usuario" => $_POST["usuario"],
																"password" => $_POST["password"],
																"email" => $_POST["email"] );

			#var_dump($datosController);
			$respuesta = Datos::registroUsuarioModel($datosController, "usuarios");

			#echo $respuesta;

			if($respuesta == "success"){
				header("location:index.php?action=registro-ok");
			}else{
				header("location:index.php?action=registro-error");
			}
		}
	}

	#Ingreso de usuarios
	#-------------------------------------
	static public function ingresoUsuarioController(){
		if(isset($_POST["usuario"]) && isset($_POST["password"]) ){
			$datosController = array(	"usuario" => $_POST["usuario"],
																"password" => $_POST["password"] );

			$respuesta = Datos::ingresoUsuarioModel($datosController, "usuarios");
			//var_dump($respuesta);
			if($respuesta["usuario"] == $_POST["usuario"] && $respuesta["password"] == $_POST["password"]){
				session_start();
				$_SESSION["validar"] = true;
				header("location:index.php?action=usuarios-ok");
			}else{
				header("location:index.php?action=ingreso-error");
			}
		}
	}

	#Vista de usuarios
	#--------------------------------------
	static public function vistaUsuariosController(){

		$respuesta = Datos::vistaUsuariosModel("usuarios");

		#constructor foreach - proporciona un modo sencillo para recorrer un array, sólo funciona sobre arrays.

		foreach ($respuesta as $row => $item) {
			echo"
			<tr>
				<td>".$item["usuario"]."</td>
				<td>".$item["password"]."</td>
				<td>".$item["email"]."</td>

				<td>
					<a href='index.php?action=editar&id=".$item["id"]."'>
						<button>Editar</button>
					</a>
				</td>

				<td><a href='index.php?action=usuarios&idBorrar=".$item["id"]."'><button>Borrar</button></a></td>
			</tr>
			";
		}
	}

	#Borrar usuarios
	#--------------------------------------
	static public function borrarUsuariosController(){
		if(isset($_GET["idBorrar"])){
			$datosController = $_GET["idBorrar"];

			$respuesta = Datos::borrarUsuariosModel($datosController, "usuarios");

			if($respuesta == "success"){
				header("location:index.php?action=usuarios-eliminado-ok");
			}else{
				header("location:index.php?action=usuarios-eliminado-error");
			}

		}
	}

	#Editar usuarios
	#-------------------------------------
	static public function editarUsuarioController(){
		if(isset($_GET["id"])){
			$datosController = $_GET["id"];
			$respuesta = Datos::editarUsuarioModel($datosController, "usuarios");
			echo '
			<input type="hidden" id="id" name="id" required value="'.$_GET["id"].'">

			<input type="text" placeholder="Usuario" id="usuario" name="usuario" required value="'.$respuesta["usuario"].'">

			<input type="password" placeholder="Contraseña" id="password" name="password" required value="'.$respuesta["password"].'">

			<input type="email" placeholder="Email" id="email" name="email" required value="'.$respuesta["email"].'">

			<input type="submit" value="Enviar">
			';
		}
	}

	#Actualizar usuarios
	#--------------------------------
	static public function actualizarUsuarioController(){
		if(isset($_POST["usuario"]) && isset($_POST["email"]) && isset($_POST["password"]) && isset($_POST["id"]) ){

			$datosController = array(
				"id"				=>	$_POST["id"],
				"usuario" 	=> 	$_POST["usuario"],
				"password"	=> 	$_POST["password"],
				"email"			=>	$_POST["email"]
			);

			$respuesta = Datos::actualizarUsuarioModel($datosController, "usuarios");
			//echo $respuesta;
			if($respuesta == "success"){
				header("location:index.php?action=editar-ok");
			}else{
				header("location:index.php?action=editar-error");
			}
		}
	}

}
/*

*/
?>
