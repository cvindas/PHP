<?php

class Paginas{

	static public function enlacesPaginasModel($enlaces){
		switch ($enlaces) {
			case "ingresar":
			$module =  "views/modules/".$enlaces.".php";
			break;

			case "usuarios":
			$module =  "views/modules/".$enlaces.".php";
			break;

			case "editar":
			$module =  "views/modules/".$enlaces.".php";
			break;

			case "salir":
			$module =  "views/modules/".$enlaces.".php";
			break;

			case "index":
			$module = "views/modules/registro.php";
			break;

			case "registro-ok":
			$module = "views/modules/registro.php";
			break;

			case "registro-error":
			$module = "views/modules/registro.php";
			break;

			case "ingreso-error":
			$module = "views/modules/ingresar.php";
			break;

			case "usuarios-ok":
			$module = "views/modules/usuarios.php";
			break;

			case "usuarios-eliminado-ok":
			$module = "views/modules/usuarios.php";
			break;

			case "usuarios-eliminado-error":
			$module = "views/modules/usuarios.php";
			break;

			case "editar-ok":
			$module = "views/modules/usuarios.php";
			break;

			case "editar-error":
			$module = "views/modules/editar.php";
			break;

			default:
			$module =  "views/modules/registro.php";
			break;
		}

		return $module;

	}

}

?>
