<?php
require_once "conexion.php";

class Datos extends Conexion{
  #Registro de usuarios
  #--------------------------------
  static public function registroUsuarioModel($datosModel, $tabla){

    #prepare() nos sirve para preparar una sentencia SQL, para ser ejecutada por el método PDO
    $stmt = Conexion::conectar()->prepare("INSERT INTO $tabla (usuario, password, email) VALUES (:usuario, :password, :email)");

    $stmt -> bindParam(":usuario", $datosModel["usuario"], PDO::PARAM_STR);
    $stmt -> bindParam(":password", $datosModel["password"], PDO::PARAM_STR);
    $stmt -> bindParam(":email", $datosModel["email"], PDO::PARAM_STR);

    if($stmt -> execute()){
      return "success";
    }else{
      return "error";
    }

    $stmt -> close();

  }
  #Ingreso de usuarios
  #--------------------------------
  static public function ingresoUsuarioModel($datosModel, $tabla){
    $stmt = Conexion::conectar()->prepare("SELECT usuario, password FROM $tabla WHERE usuario = :usuario");
    $stmt->bindParam(":usuario", $datosModel["usuario"], PDO::PARAM_STR);
    $stmt->execute();
    #fetch funciona para obtener una fila de un conjunto de resultados de la base de datos
    return $stmt->fetch();
    $stmt->close();
  }

  #Vista Usuarios
  #--------------------------------
  static public function vistaUsuariosModel($tabla){
    $stmt = Conexion::conectar()->prepare("SELECT id, password, usuario, email FROM $tabla");
    $stmt -> execute();
    #fetchAll Obtiene todas las filas de un conjunto de resultados de la base de datos
    return $stmt -> fetchAll();
    $stmt->close();
  }

  #Borrar Usuarios
  #--------------------------------
  static public function borrarUsuariosModel($datosModel, $tabla){
    $stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id = :id");
    $stmt->bindParam(":id",$datosModel, PDO::PARAM_INT);

    if($stmt -> execute()){
      return "success";
    }else{
      return "error";
    }

    $stmt -> close();
  }

  #Editar usuario
  #--------------------------------
  static public function editarUsuarioModel($datosModel, $tabla){
    $stmt = Conexion::conectar()->prepare("SELECT id, password, usuario, email FROM $tabla WHERE id=:id");
    $stmt -> bindParam(":id", $datosModel, PDO::PARAM_INT);
    $stmt -> execute();
    return $stmt -> fetch();
    $stmt->close();
  }

  #Actualizar usuario
  #--------------------------------
  static public function actualizarUsuarioModel($datosModel, $tabla){
    $stmt = Conexion::conectar()->prepare("UPDATE $tabla SET usuario = :usuario, password = :password, email = :email WHERE id = :id");

    $stmt -> bindParam(":id", $datosModel["id"],PDO::PARAM_INT);
    $stmt -> bindParam(":usuario", $datosModel["usuario"],PDO::PARAM_STR);
    $stmt -> bindParam(":password", $datosModel["password"],PDO::PARAM_STR);
    $stmt -> bindParam(":email", $datosModel["email"],PDO::PARAM_STR);

    if($stmt -> execute() ){
      return "success";
    }else{
      return "error";
    }
  }

}

 ?>
