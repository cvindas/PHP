<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dispositivos extends CI_Controller {

	public function __construct()
{
		parent::__construct();
		$this->load->model('Dispositivos_model');	//cargo el modelo
		$this->load->database();						//cargo la base de datos (me conecto)
		$this->load->library('session');		//cargo la libreria de manejo de sesiones (variables)

		if ($this->session->userdata('usuario_id')==""){
			echo "Sin autorización";
			die();
		}
}

	public function index()
	{

		$usuario_id = $this->session->userdata('usuario_id'); //recupero de variables de sesión el id del usuario para siempre mostrar o modificar valores que pertenezcan a dicho usuario
		$dispositivos = $this->Dispositivos_model->listar_dispositivos($usuario_id); //llamo a la func listar dispositivos del modelo Dispositivos_model, pasándole el userid ya que la función solo debe devolver los dispos del usuario en cuestión y NO LOS DE OTRO USUARIO. a la lista en forma de array la guardo en la variabla $dispositivos
		$data['dispositivos'] = $dispositivos; // a la lista $dispositivos la meto en un array llamado $data con 'indice' ['dispositivos'] la variable se llama $data por convención pero tranquilamente puede ser $papafrita['hamburguesa'] pero por lo general preparamos una variable con ese nombre, $data y en cada índice vamos a ir agregando cada una de las variables que queremos pasarle a la vista.

		$this->load->view('head');
		$this->load->view('abre_body_wrapper');
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('content_dispositivos',$data);
		$this->load->view('footer');
		$this->load->view('control_sidebar');
		$this->load->view('cierra_wrapper');
		$this->load->view('scripts');
	}


	public function recibe_dispositivos()
	{
		$usuario_id = $this->session->userdata('usuario_id'); //recupero de variables de sesión el id del usuario para siempre mostrar o modificar valores que pertenezcan a dicho usuario
		$alias = strip_tags($this->input->post('alias')); //limpio y recibo por post el alias del nuevo dispositivo
		$serie = strip_tags($this->input->post('serie')); //limpio y recibo por post la serie del nuevo dispositivo
		$this->Dispositivos_model->nuevo_dispositivo($usuario_id, $serie,$alias); //le envío a la función "nuevo dispositivo" del modelo "dispositivos model" los datos necesarios para que pueda grabar la nueva fila en la tabla correspondiente.

		$dispositivos = $this->Dispositivos_model->listar_dispositivos($usuario_id); //llamo a la func listar dispositivos del modelo Dispositivos_model, pasándole el userid ya que la función solo debe devolver los dispos del usuario en cuestión y NO LOS DE OTRO USUARIO. a la lista en forma de array la guardo en la variabla $dispositivos

		$data['dispositivos'] = $dispositivos; // a la lista $dispositivos la meto en un array llamado $data con 'indice' ['dispositivos'] la variable se llama $data por convención pero tranquilamente puede ser $papafrita['hamburguesa'] pero por lo general preparamos una variable con ese nombre, $data y en cada índice vamos a ir agregando cada una de las variables que queremos pasarle a la vista.

		$this->load->view('head');
		$this->load->view('abre_body_wrapper');
		$this->load->view('header');
		$this->load->view('sidebar');
		$this->load->view('content_dispositivos',$data); //le paso a la vista la variable $data.
		$this->load->view('footer');
		$this->load->view('control_sidebar');
		$this->load->view('cierra_wrapper');
		$this->load->view('scripts');

	}
}
