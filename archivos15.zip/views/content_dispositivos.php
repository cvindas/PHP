<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
<section class="content">

  <!-- MIREN QUE POR CADA FILA CON CONTENIDO PORNGO UN "ROW" ESTE ES EL ROW QUE CONTIENE EL FORM -->
<div class="row">
  <div class="col-lg-6 col-xs-6">
    <div class="box box-info">
          <div class="box-header with-border">
            <h3 class="box-title">Nuevo dispositivo</h3>
          </div>
          <!-- /.box-header -->
          <!-- form start -->
          <form class="form-horizontal" method="POST" action="<?php echo base_url('dispositivos/recibe_dispositivos')?>">
            <div class="box-body">

              <div class="form-group">
                <label for="inputEmail3" class="col-sm-2 control-label">Alias</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="inputEmail3" placeholder="Ingrese alias" name="alias">
                </div>
              </div>

              <div class="form-group">
                <label for="inputPassword3" class="col-sm-2 control-label">Serie</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="inputPassword3" placeholder="Ingrese Serie" name="serie">
                </div>
              </div>

            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <button type="submit" class="btn btn-info pull-right">REGISTRAR</button>
            </div>
            <!-- /.box-footer -->
          </form>
        </div>
      </div>
    </div>


  <!-- MIREN QUE POR CADA FILA CON CONTENIDO PORNGO UN "ROW" ESTE ES EL ROW QUE CONTIENE LA LISTA DE DISPOSITIVOS -->
    <div class="row">
      <div class="col-md-8">
          <div class="box box-info box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">Dispositivos</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">

              <?php

              foreach ($dispositivos as $dispositivo) {
                echo "Serie: ".$dispositivo['serie']." Alias: ".$dispositivo['alias']." Fecha: ".$dispositivo['fecha']."<br>";
              }

               ?>


            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
    </div>


  </section>
  </div>
