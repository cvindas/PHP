<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Dispositivos_model extends CI_Model
{
    public function nuevo_dispositivo($usuario_id,$serie,$alias)
    {

      $data = array(
        'serie' => $serie,
        'alias' => $alias,
        'usuario_id' => $usuario_id
        );

      $this->db->insert('dispositivos', $data);
    }

    public function listar_dispositivos($usuario_id)
    {
        $this->db->select('dispositivo_id,serie,alias,fecha'); // seleciono columnas de tabla dispositivos
        $this->db->from('dispositivos'); // de la tabla dispositivos
        $this->db->where('usuario_id', $usuario_id); //donde el dispositivo id = 1 (por ahora)
        $result =	$this->db->get()->result_array(); // obtengo el resultado en un array!
        //echo "<pre>";
        //print_r($result);
        //echo "<pre>";
        //die(); //descomentar estas dos líneas para debuguear...
        return $result; //devuelvo el arrray con la lista de dispositivos al controlador
    }


}
