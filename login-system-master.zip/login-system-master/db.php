<?php
$host = 'localhost';
$user = 'root';
$pass = 'root';
$db = 'inventorio';
$mysqli = new mysqli($host,$user,$pass,$db) or die($mysqli->error);
