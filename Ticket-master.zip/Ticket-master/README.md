# Ticket
Mini sistema de ticket para soporte tecnico PHP, MySQL, Bootstrap

# Datos de la cuenta del administrador
```
Usuario: Administrador
```
```
Clave: Administrador
```
# Video de la instalacion
[Ver en YouTube](https://www.youtube.com/watch?v=QWOLDwwqws8)
