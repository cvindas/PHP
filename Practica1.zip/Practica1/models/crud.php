<?php
#extends es heredar
require_once "conexion.php";
class Datos extends Conexion{
 static public function registroUsuarioModel($datosModel, $tabla){
   #var_dump($datosModel);
   #echo $tabla;
#prepare() nos permite preparar una sentencia sql, para ser ejecutada por el metodo PDO
$stmt = Conexion::conectar()->prepare("INSERT INTO $tabla (nombre, apellido, email, password) VALUES (:nombre, :apellido, :email, :password)");

$stmt -> bindParam(":nombre", $datosModel["nombre"], PDO::PARAM_STR);
$stmt -> bindParam(":apellido", $datosModel["apellido"], PDO::PARAM_STR);
$stmt -> bindParam(":email", $datosModel["email"], PDO::PARAM_STR);
$stmt -> bindParam(":password", $datosModel["password"], PDO::PARAM_STR);

if($stmt -> execute()){
  return "success";
}else{
  return "error";
}
$stmt -> close();
 }
 static public function ingresoUsuarioModel($datosModel, $tabla){
   #return $datosModel;
   $stmt = Conexion::conectar()->prepare("SELECT email, password FROM $tabla WHERE email = :email");
$stmt->bindParam(":email", $datosModel["email"], PDO::PARAM_STR);
$stmt->execute();
#fetch funciona para obtener una fila de un cojunto de resultados en la base de datos
return $stmt->fetch();
$stmt->close();

 }
 /*
#vista USUARIOS
#---------------------------------------------------------
static public function vistaUsuariosModel($tabla){
$stmt = Conexion::conectar()->prepare("SELECT id, password, usuario, email FROM $tabla");
$stmt -> execute();
#fetchALL obtiene todas las filas de un conjunto de resultados de la base de Datos
return $stmt -> fetchALL();
$stmt->close();
}

#borrar usuasrios
#-------------------------------------------
static public function borrarUsuariosModel($datosModel, $tabla){
$stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id = :id");
$stmt->bindParam(":id",$datosModel, PDO::PARAM_INT);

if($stmt -> execute()){
  return "success";
}else{
  return "error";
}
$stmt -> close();


}
#editar USUARIOS
#----------------------------------------------------------------------------
static public function editarUsuariosModel($datosModel,$tabla){
  $stmt = Conexion::conectar()->prepare("SELECT id, password, usuario, email FROM $tabla WHERE id=:id");
  $stmt -> bindParam(":id", $datosModel, PDO::PARAM_INT);
  $stmt -> execute();
  #fetchALL obtiene todas las filas de un conjunto de resultados de la base de Datos
  return $stmt -> fetch();
  $stmt->close();
  }


  */
}
 ?>
