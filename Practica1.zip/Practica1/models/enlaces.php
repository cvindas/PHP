<?php

class Paginas{

	static public function enlacesPaginasModel($enlaces){
		switch ($enlaces) {

					case "blank":
						$module =  "views/modules/".$enlaces.".php";
						break;

					case "dashboard":
						$module =  "views/modules/".$enlaces.".php";
						break;

					case "login":
						$module =  "views/modules/".$enlaces.".php";
						break;

					case "manage-users":
						$module =  "views/modules/".$enlaces.".php";
						break;

					case "examples":
						$module =  "views/modules/".$enlaces.".php";
						break;

					case "register":
						$module =  "views/modules/".$enlaces.".php";
						break;

					case "registro-ok":
						$module =  "views/modules/register.php";
						break;

					case "registro-fail":
						$module =  "views/modules/register.php";
						break;

					case "login-fail":
						$module =  "views/modules/register.php";
						break;

						case "login-ok":
							$module =  "views/modules/dashboard.php";
	          break;

					default:
						$module = "views/modules/dashboard.php";
						break;
				}

		return $module;

	}

}

?>
