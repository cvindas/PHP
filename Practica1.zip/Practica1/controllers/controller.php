<?php

class MvcController{

	#-------------------------------------

	static public function enlacesPaginasController(){

		if(isset( $_GET['action'])){

			$enlaces = $_GET['action'];

		}

		else{

			$enlaces = "dashboard";
		}

		$respuesta = Paginas::enlacesPaginasModel($enlaces);

		include $respuesta;

	}

static public function registroUsuariosController(){
	#var_dump($_POST);
	if(isset($_POST["nombre"]) && isset($_POST["apellido"]) && isset($_POST["email"]) && isset($_POST["password"])){
		$_datosController = array("nombre" => $_POST["nombre"],"apellido" => $_POST["apellido"],"email" => $_POST["email"],"password" => $_POST["password"]);
#var_dump($_datosController);
		$respuesta = Datos::registroUsuarioModel($_datosController, "usuarios");
		#echo $respuesta;
if($respuesta == "success"){
header("location:index.php?action=registro-ok");

}else{
header("location:index.php?action=registro-fail");
}

	}


}
static public function ingresoUsuarioController(){
	if(isset($_POST["email"]) && isset($_POST["password"]) ){
		$datosController = array(	"email" => $_POST["email"],
															"password" => $_POST["password"] );

		$respuesta = Datos::ingresoUsuarioModel($datosController, "usuarios");
		//var_dump($respuesta);
		if($respuesta["email"] == $_POST["email"] && $respuesta["password"] == $_POST["password"]){
			session_start();
			$_SESSION["validar"] = true;
			header("location:index.php?action=login-ok");
		}else{
			header("location:index.php?action=login-fail");
		}
	}
}

/*

	<input type="text" placeholder="Usuario" id="usuario" name="usuario" required>

	<input type="password" placeholder="Contraseña" id="password" name="password" required>

	<input type="email" placeholder="Email" id="email" name="email" required>

	<input type="submit" value="Enviar">

*/
}
?>
