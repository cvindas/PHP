<!DOCTYPE html>



<?php
require_once './inc/header.php';
require_once './inc/header2.php';
if(isset($_GET['x'])=='error'){
//    ?>
<script type="text/javascript">
        alert("<h1> Ud. Intenta burlar nuestra WEb -_- </h1>");
</script>
//<?php
}
?>  

<br>
<br>
<div   class="algin"style="background-color: #fff;width: 100%;padding: 0px;margin:  0px;">
    <center>
        <div class="algin sp" style="width: 30%;"><img style="float: right"src="img/logo_1.png"></div>
        <div class="algin sp" style="width: 48%">
            <h1 style="color:#a62b30;font-size: 20px;  font-family: Georgia, Cambria, Times, Times New Roman ; ">Institución Educatica " Pedro Ruiz Gallo"</h1>
            <br>
            <p align="justify" style="  font-family: Cambria">La Institución Educativa “Pedro Ruiz Gallo” 
                de nivel secundaria turno mañana; 
                se encuentra ubicado en el COMITE 6 - CONTISUYO S/N en 
                el distrito de Puerto Supe, provincia de Barranca UGEL 16, cuenta con 19 años impartiendo la educación Secundaria en el distrito de Puerto Supe; actualmente esta institución cuenta con un total de 360 alumnos distribuidos en el secundarios, en 13 salones, con 19 docentes a cargo y  8 personales administrativos para cubrir las diferentes áreas de la institución.</p>
        </div>
    </center>
</div>
<br>
<br>
<br>
<br>
<div class="algin"style="background-color: #e6e6e6;width: 100%;padding: 0px;margin:  0px;">
    <div>
        <center>
            <img src="img/arriba.png">
        </center>
    </div>
    <div>
        <center>
         <h1 style="color:#a62b30;font-size: 20px;  font-family: Times, Times New Roman ; ">MISION</h1>
           
                 <p align="justify" style="  font-family: Cambria;width: 50%">La Institución Educativa “Pedro Ruiz Gallo” 
           Somos una institución educativa que formamos integralmente a los adolescentes con una educación de calidad, aportando a la sociedad  ciudadanos con valores y actitudes positivas.   
        </center>
    </div>
    <div>
        <center>
            <img src="img/abajo.png">
        </center>
    </div>
   
</div>
<br>
<br>
<br>
<br>
<div class="algin"style="background-color: #fff;width: 100%;padding: 40px;margin:  0px;">
   
    <div>
        <center>
         <h1 style="color:#a62b30;font-size: 20px;  font-family: Times, Times New Roman ; ">VISION</h1>
           
                 <p align="justify" style="  font-family: Cambria;width: 50%">
        En el 2016 seremos una institución educativa de calidad basada en la práctica de valores,
        en un clima institucional democrático, donde los estudiantes son protagonistas en la 
        construcción de sus aprendizajes, que les permita desarrollar
        sus capacidades y actitudes con eficiencia y eficacia, en una sociedad pluricultural.  
        </center>
    </div>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<?php 
require_once './inc/footee.php';
?>
<style> 
    .algin{
        display: inline-block;
        vertical-align: top;
    }
    .sp{
        padding: 10px;   
    }
</style>
</html>
