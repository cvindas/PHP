<!DOCTYPE html>
<html>

    <meta charset="UTF-8">
    <title>Pedro Ruiz Gallo</title>
    <script type="text/javascript" src="./js/jquery.js"></script>
    <script type="text/javascript" src="./js/jquery.min.js"></script>
    <link href="./css/dheader.css" type="text/css"  rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="./css/estilos.css">
    <!--<link href="css/bootstrap.css" rel="stylesheet" type="text/css">-->

    <div class="contenedor_principal" style="float: left;border-bottom:1px solid"> 
        <div  class="header_principal" style="width: 25% ;float: left;" >
            <a href="index.php"><img src="img/logo.png" style="width: 100%; "></a>
        </div>
        <div  class="header_principal" align="left" style="width: 65%;">
            <nav>
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                    <li><a href="docentes.php">Docentes</a></li>
                    <li><a href="bacantes.php">Bacantes</a></li>
                    <li><a href="descargas.php">Descargas</a></li>
                    <li><a href="consultas.php?p=consultas">Consultas</a></li>
                    <li><a href="formularioApoderado.php">PREINSCRIPCION</a></li>

                </ul>
            </nav>

        </div>
        <div class="header_principal" style="float: right;width: 5%;">
            <a href="https://www.facebook.com/PSPRG?ref=hl" target="_blank"><h1 class="h1h">f</h1></a> 
        </div>
      </div>
      <br>
    </html>