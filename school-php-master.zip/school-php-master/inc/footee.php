<footer style="width: 100%;">
    <div style="background-color: #a62b30;width: 100%;">
        <div class="sizediv">

            <div class="forma">

                <div class="forma2">
                </div>            
            </div>

        </div>
       
        <div class="sizediv">

            <div class="forma">

                <div class="forma2">
                </div> 
              
            </div>
            <h4 class="x">Derechos Reservados:</h4>
            <p class="xy">
                _Suarez Loli Edson<br>
                _Huerta Mendez Juan <br>
                _Jara Mogollón Erick
            </p>
            
        </div>
        <div class="sizediv">
            <div class="forma">
                <div class="forma2">
                </div> 
            </div>
             <div  style="float: right;width: 5%;">
                 <a href="https://www.facebook.com/PSPRG?ref=hl" target="_blank"><h1 style="background-color: white;color: black;border-radius: 30px 30px 30px 30px">f</h1></a> 
        </div>
        </div>

    </div>
    <style>
        .sizediv{
            width:400px;
            display: inline-block;vertical-align: top;
            padding: 0px;
            margin: 0px;
        }

        .forma{
            /*width: 0%;*/ 
            border-left: 420px solid transparent;
            border-right:120px solid transparent; 
            border-top: 120px solid #fff;


        }
        .forma2{
            /*width: 0; 
            */border-left:0px solid transparent; 
            border-right: 10px solid transparent; 
            border-top: 14px solid #a62b30;
        }
        .x{
            color: white;
            font-size: 20px;
            font-family: calibri;
        }
        .xy{
            color: white;
            font-size: 14px;
            font-family: calibri;
            
        }

    </style>
</footer>
