<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Intrananet Docente</title>
        <link href="../css/general_style.css" type="text/css" rel="stylesheet">
        <link href="../css/bootstrap.css" type="text/css" rel="stylesheet">
        <link href="../css/jquery-ui-1.8.16.custom.css" type="text/css" rel="stylesheet">
        <link href="../css/bootstrap.css" type="text/css" rel="stylesheet">
        <link href="../css/nav.css" type="text/css" rel="stylesheet">
        <link href="../js/jquery-ui.css" rel="stylesheet" type="text/css">
        <link href="../js/jquery-ui.min.css" rel="stylesheet" type="text/css">
        <link href="../css/formulario.css"  type="text/css" rel="stylesheet">
        <meta charset="utf-8">
    </head>
    
    <div align="center" class="colorhead">

        <img src="../img/logoX.png" >
        <div style="width: 8%;float: right;background-color: #a13302">
          <details >
                    <summary style="text-decoration: none;float: right" >
                        <img src="../img/menu01.png" style="float: right">
                    </summary>
              <small style="text-align: left;padding: 3px;">
                  <h6 class="h6">Bienvenido</h6>
                        <a class="ax"href="#">ver perfil</a><br>
                        <a class="ax"href="#">mi agenda</a><br>
                        <a  class="ax"href="../cerrar_session.php" >salir</a>

                    </small>
                </details>
            <style>
                .ax{
                    color: #fff;
                    font-family: calibri,arial,thempus;
                   
                }
            </style>
    </div>
    </div>
    <div id="header">
                <ul class="nav">
            <li><a href="../VISTA/perfil_director.php" >Perfil</a></li>
            <li><a  href="../VISTA/listar_alumno.php">Lista de Alumnos</a></li>

            <li><a  href="../VISTA/registro_trimestre.php">Asignar Trimestres</a></li>
            <li><a  href="../VISTA/carga_lectiva.php">Carga Lectiva</a></li>
            <li><a  href="../VISTA/asignatura.php">Asignatura</a></li>
            <li><a  href="../VISTA/sclases.php">Salon de clases</a></li>
            <li><a href="">Registrar</a>
                <ul>
                    <li><a  href="../VISTA/formulario_docente.php"> Docente</a></li>
                    <li><a  href="../VISTA/formulario_alumno.php"> Alumno</a></li>
                    <li><a  href="../VISTA/requisitos.php"> Requisitos</a></li>
                    <li><a  href="../VISTA/pagos.php">Pagos</a></li>
                </ul>
            </li>
<li><a  href="../VISTA/horario.php">Horarios</a></li>
        </ul>
    </div>
   
    <br>




</head>



</body>
</html>
</html>
