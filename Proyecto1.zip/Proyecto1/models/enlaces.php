<?php

class Paginas{

	static public function enlacesPaginasModel($enlaces){
		switch ($enlaces) {

					case "about":
						$module =  "views/modules/".$enlaces.".php";
						break;

						case "booking":
							$module =  "views/modules/".$enlaces.".php";
							break;

					case "contact":
						$module =  "views/modules/".$enlaces.".php";
						break;

					case "home":
						$module =  "views/modules/".$enlaces.".php";
						break;

					case "gallery":
						$module =  "views/modules/".$enlaces.".php";
						break;

					case "icons":
						$module =  "views/modules/".$enlaces.".php";
						break;

					case "typography":
						$module =  "views/modules/".$enlaces.".php";
						break;

						default:
						$module = "views/modules/home.php";
						break;

						case "registro-ok":
							$module =  "views/modules/home.php";
							break;

						case "registro-fail":
							$module =  "views/modules/contact.php";
							break;
				}

		return $module;

	}

}

?>
