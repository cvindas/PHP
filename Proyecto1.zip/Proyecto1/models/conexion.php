<?php
class Conexion{
  static public function conectar(){
    $enlaces = new PDO("mysql:host=localhost;dbname=travel","root","");
#    var_dump($enlaces);
return $enlaces;
  }
}


#$a=new conexion();
#$a -> conectar();

 ?>
